<?php
return array(
    //通知方法
    "REMINDER_EMAIL" => 1,
    "REMINDER_SMS" => 2,
    "REMINDER_POPUP" => 3,

    // 休日設定CSV項目数
    "HOLIDAY_CSV_COLUMNS" => 3,
    // 休日設定予定カラー
    "HOLIDAY_EVENT_COLOR" => "#e84b64",
    "HOLIDAY_TEXT_COLOR" => "#ffffff",
);
