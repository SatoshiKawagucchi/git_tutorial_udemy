# COMPONENTS

The components directory contains your Vue.js Components.
Nuxt.js doesn't supercharge these components.

**This directory is not required, you can delete it if you don't want to use it.**

## Install

npm install -g @vue/cli
npm install -g npm-check-updates

* ncuコマンドだけだと、変更前と変更後のリストが表示されるだけで、package.jsonはまだ書き替わらないので安心。

ncu
* -uオプションをつけるとpackage.jsonが更新される
ncu -u
npm install
