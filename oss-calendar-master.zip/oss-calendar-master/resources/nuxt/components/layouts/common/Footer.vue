<template>
  <v-footer :fixed="$store.getters.getFixed" app>
    <span>&copy; 2019 ThinkingReed Inc.</span>
  </v-footer>
</template>

<script>
export default {
  data() {
    return {}
  }
}
</script>
